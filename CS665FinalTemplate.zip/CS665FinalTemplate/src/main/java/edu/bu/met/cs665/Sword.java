package edu.bu.met.cs665;
import edu.bu.met.cs665.Weapon;

public class Sword extends Weapon {
    public Sword(Enhancement enhancement, int attackDamage, int attackSpeed) {
        super(enhancement, attackDamage, attackSpeed);
    }

    /**
     * Enhanced the weapon with the data of the enhancement.
     * the sword have the based attack damage of 20, and based attack speed of 20
     */
    @Override
    public void applyEnhancement() {
        this.attackDamage = 20+ enhancement.changeDamage(this.attackDamage);
        this.attackSpeed = 20 + enhancement.changeSpeed(this.attackSpeed);
        System.out.println("Sword after enhanced: Damage - " + (20 + this.attackDamage ) + ", Speed -- " + (20 +  this.attackSpeed));
    }

    /**
     * the showWeapon println the attack damage and attack speed of the weapon
     */
	@Override
	public void showWeapon() {
			 System.out.println("Your sword state now: Damage -- " + (20 + this.attackDamage ) + ", Speed -- " + (20 +  this.attackSpeed));
	}
}
