package edu.bu.met.cs665;
/**
 * 
 *The interface of Observe, which can help implement the observe design pattern
 *
 */
public interface Observer {
    void update(Weapon weapon);
}