package edu.bu.met.cs665;

import java.util.ArrayList;
import java.util.List;

/**
 * The abstract class of Weapon, define the Weapon has attribute of enhancement, attackDamage, attackSpeed.
 * Have child class of Knife.java and Sword.java
 *
 */
public abstract class Weapon {
    protected Enhancement enhancement;
    protected int attackDamage;
    protected int attackSpeed;

    /**
     * The constructor of Weapon.java
     * @param enhancement
     * @param attackDamage
     * @param attackSpeed
     */
    public Weapon(Enhancement enhancement, int attackDamage, int attackSpeed) {
        this.enhancement = enhancement;
        this.attackDamage = attackDamage;
        this.attackSpeed = attackSpeed;
    }
    
    public Enhancement getEnhancement() {
    	return this.enhancement;
    }
    
    public void setEnhancement(Enhancement enhancement) {
    	this.enhancement = enhancement;
    }

    public int getAttackDamage() {
    	return this.attackDamage;
    }
    
    public void setAttackDamage(int damage) {
    	this.attackDamage = damage;
    }
    
    public int getAttackSpeed() {
    	return this.attackSpeed;
    }
    
    public void setAttackSpeed(int speed) {
    	this.attackSpeed = speed;
    }
    
    
    public abstract void showWeapon();
    public abstract void applyEnhancement();
    
    /**
     * The Observe part, which can help to implement the observe design pattern
     */
    private List<Observer> observers = new ArrayList<>();

    public void attach(Observer observer) {
        observers.add(observer);
    }

    public void detach(Observer observer) {
        observers.remove(observer);
    }

    protected void notifyObservers() {
        for (Observer observer : observers) {
            observer.update(this);
        }
    }

   /**
    * call the observe function, help to implement the observe design pattern
    */
    protected void enhancementApplied() {
        notifyObservers();
    }
    
    
}