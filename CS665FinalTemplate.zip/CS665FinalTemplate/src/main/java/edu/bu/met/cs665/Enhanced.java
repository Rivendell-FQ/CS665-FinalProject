package edu.bu.met.cs665;
import edu.bu.met.cs665.Enhancement;
/**
 * 
 * The Enhanced class, which implements the Enhacement.java interface.
 * Enhanced have the attribute of chagnedDamage and changedSpeed.
 * And have changedDamage and changeSpeed method which can add damage or speed into the Weapon's data
 *
 */
public class Enhanced implements Enhancement {
    private int changedDamage;
    private int changedSpeed;

    /**
     * The constructor method the Enhanced
     */
    public Enhanced(int changedDamage, int changedSpeed) {
        this.changedDamage = changedDamage;
        this.changedSpeed = changedSpeed;
    }
    
    /**
     * changedDamage can return the damage after add the enhanced data into the weapon's data of damage
     * @return int
     */
    @Override
    public int changeDamage(int damage) {
        return damage + changedDamage;
    }

    /**
     * changedSpeed can return the speed after add the enhanced data into the weapon's data of speed
     * @return int
     */
    @Override
    public int changeSpeed(int speed) {
        return speed + changedSpeed;
    }
 
    public int getChangedDamage() {
    	return this.changedDamage;
    }
    
    public int getChangedSpeed() {
    	return this.changedSpeed;
    }
    
    public void setChangedDamage(int damage) {
    	this.changedDamage = damage;
    }
    
    public void setChangedSpeed(int speed) {
    	this.changedSpeed = speed;
    }
}