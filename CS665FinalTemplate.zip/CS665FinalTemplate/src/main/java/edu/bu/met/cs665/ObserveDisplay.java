package edu.bu.met.cs665;

/**
 * The Observe display class, which implement the Observer.java as interface.
 * have update method which can help observe the data of weapon after enhanced
 */
public class ObserveDisplay implements Observer {
    @Override
    public void update(Weapon weapon) {
        System.out.println("Weapon Status Updated: " + weapon.getClass().getSimpleName() 
                           + " - Attack Damage: " + weapon.getAttackDamage() 
                           + ", Attack Speed: " + weapon.getAttackSpeed());
    }
}