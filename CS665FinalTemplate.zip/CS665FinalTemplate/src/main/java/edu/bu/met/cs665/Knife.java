package edu.bu.met.cs665;
import edu.bu.met.cs665.Weapon;

public class Knife extends Weapon {
    public Knife(Enhancement enhancement, int attackDamage, int attackSpeed) {
        super(enhancement, attackDamage, attackSpeed);
    }

    /**
     * Enhanced the weapon with the data of the enhancement.
     * the knife have the based attack damage of 10, and based attack speed of 10
     */
    @Override
    public void applyEnhancement() {
        this.attackDamage = 10 + enhancement.changeDamage(this.attackDamage);
        this.attackSpeed = 10 + enhancement.changeSpeed(this.attackSpeed);
        System.out.println("Knife after enhanced: Damage -- " + (10 + this.attackDamage ) + ", Speed -- " + (10 +  this.attackSpeed));
    }

    /**
     * the showWeapon println the attack damage and attack speed of the weapon
     */
	@Override
	public void showWeapon() {
		 System.out.println("Your knife state now: Damage -- " + (10 + this.attackDamage ) + ", Speed -- " + (10 +  this.attackSpeed));
	}
}
