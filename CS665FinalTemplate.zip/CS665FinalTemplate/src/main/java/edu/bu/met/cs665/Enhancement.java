package edu.bu.met.cs665;

/**
 * 
 * The interface about the Enhancement, help define Enhaced.java
 *
 */
public interface Enhancement {
    int changeDamage(int damage);
    int changeSpeed(int speed);
    int getChangedDamage();
    int getChangedSpeed();
}