package edu.bu.met.cs665;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import edu.bu.met.cs665.Enhanced;
import edu.bu.met.cs665.Enhancement;
import edu.bu.met.cs665.Sword;
import edu.bu.met.cs665.Knife;
import edu.bu.met.cs665.Weapon;

/**
 * 
 * The main class of the 665 final project - about the bridge design pattern
 * using GUI and txt to show the data changed after enhanced the weapon
 * 
 * Qi Feng - CS665 Final project - 2023.12.12
 *
 */
public class Bridge {

    	private JFrame frame;
	    private JPanel panel;
	    private JComboBox<String> weaponTypeComboBox;
	    private JTextField attackDamageField;
	    private JTextField attackSpeedField;
	    private JTextField changeDamageField;
	    private JTextField changeSpeedField;
	    private JButton enhanceButton;
	    private JLabel resultLabel;

	    public Bridge() {
	        frame = new JFrame();
	        panel = new JPanel();
	        frame.setSize(300, 300);
	        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        frame.add(panel);
	        panel.setLayout(null);

	        weaponTypeComboBox = new JComboBox<>(new String[]{"Knife", "Sword"});
	        weaponTypeComboBox.setBounds(10, 20, 80, 25);
	        panel.add(weaponTypeComboBox);

	        attackDamageField = new JTextField(20);
	        attackDamageField.setBounds(100, 20, 165, 25);
	        panel.add(attackDamageField);

	        attackSpeedField = new JTextField(20);
	        attackSpeedField.setBounds(100, 50, 165, 25);
	        panel.add(attackSpeedField);

	        changeDamageField = new JTextField(20);
	        changeDamageField.setBounds(100, 110, 165, 25);
	        panel.add(changeDamageField);

	        changeSpeedField = new JTextField(20);
	        changeSpeedField.setBounds(100, 140, 165, 25);
	        panel.add(changeSpeedField);

	        enhanceButton = new JButton("Enhanced");
	        enhanceButton.setBounds(10, 140, 80, 25);
	        panel.add(enhanceButton);
	        enhanceButton.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	                enhanceWeapon();
	            }
	        });

	        resultLabel = new JLabel("");
	        resultLabel.setBounds(10, 170, 280, 25);
	        panel.add(resultLabel);

	        frame.setVisible(true);
	    }

	    private void enhanceWeapon() {
	        String weaponType = (String) weaponTypeComboBox.getSelectedItem();
	        int attackDamage = Integer.parseInt(attackDamageField.getText());
	        int attackSpeed = Integer.parseInt(attackSpeedField.getText());
	        int changeDamage = Integer.parseInt(changeDamageField.getText());
	        int changeSpeed = Integer.parseInt(changeSpeedField.getText());

	        Enhancement enhancement = new Enhanced(changeDamage, changeSpeed);
	        Weapon weapon;

	        if (weaponType.equals("Knife")) {
	            weapon = new Knife(enhancement, attackDamage, attackSpeed);
	        } else { 
	            weapon = new Sword(enhancement, attackDamage, attackSpeed);
	        }

	        weapon.applyEnhancement();
	        resultLabel.setText("Enhanced " + weaponType + ": Damage - " + weapon.getAttackDamage() + ", Speed - " + weapon.getAttackSpeed());
	    }

	    /**
	     * The main method of the project
	     * @param args
	     */
	    public static void main(String[] args) {
	        new Bridge();
	 
	        System.out.println("Welcome to the Bridge Pattern Example. The Sword has 20 based damage and speed. Knife has 10 based damage and speed.");
	         Enhancement noEnhancement = new Enhanced(0, 0);
			 Enhancement enhancement1 = new Enhanced(20, 20);
			 Enhancement attackEnhancement1 = new Enhanced(50,0);
			 Enhancement speedEnhancement1 = new Enhanced(0,50);
			 
			 
		     Weapon sword1 = new Sword(enhancement1, 20, 20);
		     sword1.showWeapon();
		     sword1.applyEnhancement();
		     
		     Weapon knife1 = new Knife(noEnhancement, 10, 10);
		     sword1.showWeapon();
		     knife1.applyEnhancement();
		
	        Observer display = new ObserveDisplay();
	        sword1.attach(display);
	    }
	
	

	
}
