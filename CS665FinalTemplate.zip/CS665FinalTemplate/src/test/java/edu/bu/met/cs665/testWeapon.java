package edu.bu.met.cs665;
import static org.junit.Assert.assertEquals;

import org.junit.Test;

import edu.bu.met.cs665.Weapon;
import edu.bu.met.cs665.Enhanced;

/**
 * 
 * The tester for Weapon.java. test the methods of : getAttackDamage(), getAttackSpeed()
 *
 */
public class testWeapon {

	public testWeapon() {	
	}
	
    @Test
    public void testGetAttackDamage() {

    	Enhancement Enhanced1 = new Enhanced(0,0);
        Weapon weapon1 = new Sword(Enhanced1,10,10);
        assertEquals(10, weapon1.getAttackDamage());
        
        Enhancement Enhanced2 = new Enhanced(10,10);
        Weapon weapon2 = new Sword(Enhanced2,10,10);
        assertEquals(10, weapon2.getAttackDamage());
        
        Enhancement Enhanced3 = new Enhanced(20,20);
        Weapon weapon3 = new Sword(Enhanced3,20,20);
        weapon3.applyEnhancement();
        assertEquals(40, weapon3.getAttackDamage());

    }
    
    public void testGetAttackSpeed() {

    	Enhancement Enhanced1 = new Enhanced(0,0);
        Weapon weapon1 = new Sword(Enhanced1,10,10);
        assertEquals(10, weapon1.getAttackSpeed());
        
        Enhancement Enhanced2 = new Enhanced(10,10);
        Weapon weapon2 = new Sword(Enhanced2,10,10);
        assertEquals(10, weapon2.getAttackSpeed());
        
        Enhancement Enhanced3 = new Enhanced(20,20);
        Weapon weapon3 = new Sword(Enhanced3,20,20);
        weapon3.applyEnhancement();
        assertEquals(40, weapon3.getAttackSpeed());

    }
	
}
