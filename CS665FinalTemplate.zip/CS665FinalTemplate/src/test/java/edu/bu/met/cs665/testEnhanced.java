package edu.bu.met.cs665;
import static org.junit.Assert.assertEquals;

import org.junit.Test;

import edu.bu.met.cs665.Enhanced;

/**
 * 
 * The tester for Enhanced.java. test the methods of : changeDamate(),changeSpeed(), getChangedDamage, getChangedSpeed
 *
 */
public class testEnhanced {

	public testEnhanced() {	
	}
	

	 @Test
	    public void testChangeDamage() {

	    	Enhancement Enhanced1 = new Enhanced(0,0);
	        assertEquals(0, Enhanced1.changeDamage(0));
	        
	        Enhancement Enhanced2 = new Enhanced(10,10);
	        assertEquals(20, Enhanced2.changeDamage(10));
	        
	        Enhancement Enhanced3 = new Enhanced(20,20);
	        assertEquals(40, Enhanced3.changeDamage(20));
	    }
	 
	 @Test
	    public void testChangeSpeed() {

	    	Enhancement Enhanced1 = new Enhanced(0,0);
	        assertEquals(0, Enhanced1.changeSpeed(0));
	        
	        Enhancement Enhanced2 = new Enhanced(10,10);
	        assertEquals(20, Enhanced2.changeSpeed(10));
	        
	        Enhancement Enhanced3 = new Enhanced(20,20);
	        assertEquals(40, Enhanced3.changeSpeed(20));
	    }
	
	
	 @Test
	    public void testGetChangedDamage() {

	    	Enhancement Enhanced1 = new Enhanced(0,0);
	        assertEquals(0, Enhanced1.getChangedDamage());
	        
	        Enhancement Enhanced2 = new Enhanced(10,10);
	        assertEquals(10, Enhanced2.getChangedDamage());
	        
	        Enhancement Enhanced3 = new Enhanced(20,20);
	        assertEquals(20, Enhanced3.getChangedDamage());
	    }
	 
	 @Test
	    public void testGetChangedSpeed() {

	    	Enhancement Enhanced1 = new Enhanced(0,0);
	        assertEquals(0, Enhanced1.getChangedSpeed());
	        
	        Enhancement Enhanced2 = new Enhanced(10,10);
	        assertEquals(10, Enhanced2.getChangedSpeed());
	        
	        Enhancement Enhanced3 = new Enhanced(20,20);
	        assertEquals(20, Enhanced3.getChangedSpeed());
	    }
	
	
}
